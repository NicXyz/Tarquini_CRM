package crm.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import crm.db.OffertaRepository;
import crm.model.Offerta;

@Service
public class OffertaService {

	@Autowired
	OffertaRepository offertaRepository;
	
	public Offerta inserisciOfferta(Offerta o) {
		return offertaRepository.save(o);
	}
	
	public Offerta aggiornaOfferta(Integer id, Offerta o) {
		Offerta offertaDaAggiornare = offertaRepository.findByIdOfferta(id);
		
		offertaDaAggiornare.setDescrizione(o.getDescrizione());

		return offertaRepository.save(offertaDaAggiornare);
	}
	
	public Offerta eliminaOfferta(Integer id) {
		Offerta offerta = offertaRepository.findById(id).orElse(null);
		if(offerta!=null) {
			offertaRepository.delete(offerta);
			return offerta;
		} else {
			return null;
		}
	}
}
