package crm.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import crm.db.ClienteRepository;
import crm.model.Cliente;

@Service
public class ClienteService {
	
	@Autowired
	ClienteRepository clienteRepository;
	
	public Cliente inserisciCliente(Cliente c) {
		return clienteRepository.save(c);
	}
	
	public Cliente aggiornaCliente(Integer id, Cliente c) {
		Cliente clienteDaAggiornare = clienteRepository.findByIdCliente(id);
		
		clienteDaAggiornare.setNome(c.getNome());
		clienteDaAggiornare.setCognome(c.getCognome());
		clienteDaAggiornare.setDdn(c.getDdn());
		clienteDaAggiornare.setCf(c.getCf());
		clienteDaAggiornare.setIndirizzo(c.getIndirizzo());
		clienteDaAggiornare.setEmail(c.getEmail());
		clienteDaAggiornare.setTelefono(c.getTelefono());
		clienteDaAggiornare.setInvioOfferte(c.getInvioOfferte());
		clienteDaAggiornare.setIdOfferta(c.getIdOfferta());

		return clienteRepository.save(clienteDaAggiornare);
	}
	
	public Cliente eliminaCliente(Integer id) {
		Cliente cliente = clienteRepository.findById(id).orElse(null);
		if(cliente!=null) {
			clienteRepository.delete(cliente);
			return cliente;
		} else {
			return null;
		}	
	}
}
