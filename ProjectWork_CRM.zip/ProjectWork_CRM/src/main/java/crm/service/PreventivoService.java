package crm.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import crm.db.PreventivoRepository;
import crm.model.Preventivo;

@Service
public class PreventivoService {
	
	@Autowired
	PreventivoRepository preventivoRepository;
	
	public Preventivo inserisciPreventivo(Preventivo p) {
		return preventivoRepository.save(p);
	}
	
	public Preventivo aggiornaPreventivo(Integer id, Preventivo p) {
		Preventivo preventivoDaAggiornare = preventivoRepository.findByIdPreventivo(id);
		
		preventivoDaAggiornare.setPrezzo(p.getPrezzo());
		preventivoDaAggiornare.setIdOfferta(p.getIdOfferta());
		preventivoDaAggiornare.setIdCliente(p.getIdCliente());

		return preventivoRepository.save(preventivoDaAggiornare);
	}
	
	public Preventivo eliminaPreventivo(Integer id) {
		Preventivo preventivo = preventivoRepository.findById(id).orElse(null);
		if(preventivo!=null) {
			preventivoRepository.delete(preventivo);
			return preventivo;
		} else {
			return null;
		}
	}
}
