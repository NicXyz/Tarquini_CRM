package crm.db;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import crm.model.Offerta;

@Repository
public interface OffertaRepository extends CrudRepository<Offerta, Integer> {
	
	Offerta findByIdOfferta(Integer idOfferta);
	
}
