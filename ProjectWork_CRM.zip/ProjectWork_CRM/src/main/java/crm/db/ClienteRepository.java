package crm.db;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import crm.model.Cliente;

@Repository
public interface ClienteRepository extends CrudRepository<Cliente, Integer> {
	
	Cliente findByIdCliente(Integer idCliente);
	
}
