package crm.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

@Entity
@Table(name="cliente")
public class Cliente {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "id_cliente", nullable=true)
	private Integer idCliente;
	
	@Column(name = "nome")
	private String nome;
	
	@Column(name = "cognome")
	private String cognome;
	
	@Column(name = "ddn")
	private Date ddn;
	
	@Column(name = "cf")
	private String cf;
	
	@Column(name = "indirizzo")
	private String indirizzo;

	@Pattern(regexp = "(.+?)@(.+?)")
	@Column(name = "email")
	private String email;
	
	@Column(name = "telefono")
	private String telefono;
	
	@Column(name = "invio_offerte")
	private Boolean invioOfferte;
	
	@Column(name = "id_offerta")
	private Integer idOfferta;
	
	// Getters & Setters
	public Integer getIdCliente() {
		return idCliente;
	}
	public void setIdCliente(Integer idCliente) {
		this.idCliente = idCliente;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCognome() {
		return cognome;
	}
	public void setCognome(String cognome) {
		this.cognome = cognome;
	}
	public Date getDdn() {
		return ddn;
	}
	public void setDdn(Date ddn) {
		this.ddn = ddn;
	}
	public String getCf() {
		return cf;
	}
	public void setCf(String cf) {
		this.cf = cf;
	}
	public String getIndirizzo() {
		return indirizzo;
	}
	public void setIndirizzo(String indirizzo) {
		this.indirizzo = indirizzo;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getTelefono() {
		return telefono;
	}
	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}
	public Boolean getInvioOfferte() {
		return invioOfferte;
	}
	public void setInvioOfferte(Boolean invioOfferte) {
		this.invioOfferte = invioOfferte;
	}
	public Integer getIdOfferta() {
		return idOfferta;
	}
	public void setIdOfferta(Integer idOfferta) {
		this.idOfferta = idOfferta;
	}
	
	// ToString Method
	@Override
	public String toString() {
		return "Cliente [idCliente=" + idCliente + ", nome=" + nome + ", cognome=" + cognome + ", ddn=" + ddn + ", cf="
				+ cf + ", indirizzo=" + indirizzo + ", email=" + email + ", telefono=" + telefono + ", invioOfferte="
				+ invioOfferte + ", idOfferta=" + idOfferta + "]";
	}
	
}
