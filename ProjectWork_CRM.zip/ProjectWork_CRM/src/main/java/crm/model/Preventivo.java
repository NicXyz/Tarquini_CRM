package crm.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="preventivo")
public class Preventivo {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "id_preventivo", nullable=true)
	private Integer idPreventivo;
	
	@Column(name = "prezzo")
	private Double prezzo;
	
	@Column(name = "id_offerta")
	private Integer idOfferta;
	
	@Column(name = "id_cliente")
	private Integer idCliente;
	
	// Getters & Setters
	public Integer getIdPreventivo() {
		return idPreventivo;
	}
	public void setIdPreventivo(Integer idPreventivo) {
		this.idPreventivo = idPreventivo;
	}
	public Double getPrezzo() {
		return prezzo;
	}
	public void setPrezzo(Double prezzo) {
		this.prezzo = prezzo;
	}
	public Integer getIdOfferta() {
		return idOfferta;
	}
	public void setIdOfferta(Integer idOfferta) {
		this.idOfferta = idOfferta;
	}
	public Integer getIdCliente() {
		return idCliente;
	}
	public void setIdCliente(Integer idCliente) {
		this.idCliente = idCliente;
	}
	
	// ToString Method
	@Override
	public String toString() {
		return "Preventivo [idPreventivo=" + idPreventivo + ", prezzo=" + prezzo + ", idOfferta=" + idOfferta
				+ ", idCliente=" + idCliente + "]";
	}
	
}
