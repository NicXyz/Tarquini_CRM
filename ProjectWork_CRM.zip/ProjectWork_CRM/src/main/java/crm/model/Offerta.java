package crm.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="offerta")
public class Offerta {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "id_offerta", nullable=true)
	private Integer idOfferta;
	
	@Column(name = "descrizione")
	private String descrizione;
	
	// Getters & Setters
	public Integer getIdOfferta() {
		return idOfferta;
	}
	public void setIdOfferta(Integer idOfferta) {
		this.idOfferta = idOfferta;
	}
	public String getDescrizione() {
		return descrizione;
	}
	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}
	
	// ToString Method
	@Override
	public String toString() {
		return "Offerta [idOfferta=" + idOfferta + ", descrizione=" + descrizione + "]";
	}
	
}
