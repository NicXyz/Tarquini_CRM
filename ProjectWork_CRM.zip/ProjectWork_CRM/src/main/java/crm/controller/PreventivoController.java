package crm.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import crm.db.PreventivoRepository;
import crm.model.Preventivo;
import crm.service.PreventivoService;

@RestController
public class PreventivoController {
	
	@Autowired
	PreventivoRepository preventivoRepository;
	
	@Autowired
	PreventivoService preventivoService;
	
	@GetMapping("/preventivi")
	public Iterable<Preventivo> vediPreventivo() {
		return preventivoRepository.findAll();
	}
	
	@PostMapping(value="/preventivo")
	public Preventivo Preventivo(@RequestBody Preventivo p) {
		return preventivoService.inserisciPreventivo(p);
	}
	
	@RequestMapping(value="/preventivo/{idPreventivo}", method=RequestMethod.PUT)
	public Preventivo modificaPreventivo(@PathVariable("idPreventivo")Integer idPreventivo, @RequestBody Preventivo p) {
		return preventivoService.aggiornaPreventivo(idPreventivo, p);
	}
	
	@DeleteMapping("/preventivo/{idPreventivo}")
	public Preventivo cancellaPreventivo(@PathVariable("idPreventivo")Integer idPreventivo) {
		return preventivoService.eliminaPreventivo(idPreventivo);
	}
}
