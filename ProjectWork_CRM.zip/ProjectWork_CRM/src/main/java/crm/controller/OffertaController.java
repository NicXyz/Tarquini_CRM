package crm.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import crm.db.OffertaRepository;
import crm.model.Offerta;
import crm.service.OffertaService;

@RestController
public class OffertaController {
	
	@Autowired
	OffertaRepository offertaRepository;
	
	@Autowired
	OffertaService offertaService;
	
	@GetMapping("/offerte")
	public Iterable<Offerta> vediChiamate() {
		return offertaRepository.findAll();
	}
	
	@PostMapping(value="/offerta")
	public Offerta inserisciOfferta(@RequestBody Offerta a) {
		return offertaService.inserisciOfferta(a);
	}
	
	@RequestMapping(value="/offerta/{idOfferta}", method=RequestMethod.PUT)
	public Offerta modificaOfferta(@PathVariable("idOfferta")Integer idOfferta, @RequestBody Offerta o) {
		return offertaService.aggiornaOfferta(idOfferta, o);
	}
	
	@DeleteMapping("/offerta/{idOfferta}")
	public Offerta cancellaOfferta(@PathVariable("idOfferta")Integer idOfferta) {
		return offertaService.eliminaOfferta(idOfferta);
	}

}
