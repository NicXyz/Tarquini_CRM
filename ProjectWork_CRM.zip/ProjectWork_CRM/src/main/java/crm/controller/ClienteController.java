package crm.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import crm.db.ClienteRepository;
import crm.model.Cliente;
import crm.service.ClienteService;

@RestController
public class ClienteController {
	
	@Autowired
	ClienteRepository clienteRepository;
	
	@Autowired
	ClienteService clienteService;
	
	@GetMapping("/clienti")
	public Iterable<Cliente> vediClienti() {
		return clienteRepository.findAll();
	}
	
	@PostMapping(value="/cliente")
	public Cliente inserisciCliente(@RequestBody Cliente a) {
		return clienteService.inserisciCliente(a);
	}
	
	@RequestMapping(value="/cliente/{idCliente}", method=RequestMethod.PUT)
	public Cliente modificaCliente(@PathVariable("idCliente")Integer idCliente, @RequestBody Cliente a) {
		return clienteService.aggiornaCliente(idCliente, a);
	}
	
	@DeleteMapping("/cliente/{idApiario}")
	public Cliente cancellaCliente(@PathVariable("idCliente")Integer idCliente) {
		return clienteService.eliminaCliente(idCliente);
	}
}
