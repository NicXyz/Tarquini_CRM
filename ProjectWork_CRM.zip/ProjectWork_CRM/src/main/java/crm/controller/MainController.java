package crm.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class MainController {
	
	@GetMapping("/")
	public String menu() {
		return "menu";
	}
	
	@GetMapping("/inserisci")
	public String inviaSceltaInserimento() {
		return "inserisci";
	}
	@GetMapping("/liste")
	public String inviaSceltaLista() {
		return "liste";
	}
	@GetMapping("/modifica")
	public String inviaSceltaModifica() {
		return "modifica";
	}
	@GetMapping("/elimina")
	public String inviaSceltaEliminazione() {
		return "elimina";
	}
	
	@GetMapping("/cliente")
	public String inviaCliente() {
		return "cliente";
	}
	@GetMapping("/offerta")
	public String inviaOfferta() {
		return "offerta";
	}
	@GetMapping("/preventivo")
	public String inviaPreventivo() {
		return "preventivo";
	}
}


